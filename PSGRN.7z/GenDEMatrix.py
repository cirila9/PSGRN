import csv
import pandas as pd
import time
#from numba import *
import multiprocessing
import random
#from tqdm import trange
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from multiprocessing import cpu_count
from concurrent.futures import ProcessPoolExecutor
#import copent  # Jian Ma. Estimating Transfer Entropy via Copula Entropy. arXiv preprint arXiv:1910.04375, 2019.

# construct maize500, maize1000 datasets
genes = pd.read_csv('all_genes.csv', index_col=0, engine='c')
genes_list = list(genes.index)
genes = genes.values
# print(np.isnan(genes))
tfs = pd.read_csv('all_tf.csv', index_col=0, engine='c')
tfs_list = list(tfs.index)
gold = pd.read_csv('GSE137972_TF_target_TIP.csv', engine='c').values


# @jit(nopython=True)
def extract_subdatasets(genes, genes_list, tfs_list, gold, size):
    print('Dataset Extracting......')
    u = 0
    pair = np.ones((1, gold.shape[1]))
    pair_list = []
    sub_tf, sub_gene = [], []
    sub_tf_exp, sub_gene_exp = np.zeros((1, genes.shape[1])), np.zeros((1, genes.shape[1]))
    for i in range(len(gold)):
        tf_name = gold[i, 0][-14:]
        target_name = gold[i, 1]
        p_value = gold[i, 2]
        if tf_name in tfs_list and target_name in genes_list:
            if np.mean(genes[genes_list.index(tf_name), :]) > 1 and np.mean(
                    genes[genes_list.index(target_name), :]) > 1 and p_value < 0.01:
                temp = np.array([tf_name, target_name, p_value])
                pair = np.vstack((pair, temp))
    pair = pair[1:, :]
    gold_sort = pair[np.argsort(pair[:, 2], ), :]
    print(len(gold), len(gold_sort))
    for i in range(len(gold_sort)):
        # pair_list.append(str(gold_sort[i,0]+','+gold_sort[i,1]))
        if gold_sort[i][0] not in sub_tf:
            sub_tf.append(gold_sort[i][0])
        if gold_sort[i][0] not in sub_gene:
            sub_gene.append(gold_sort[i][0])
            sub_gene_exp = np.vstack((sub_gene_exp, np.abs(genes[genes_list.index(gold_sort[i][0])])))
        if gold_sort[i][1] in tfs_list and gold_sort[i][1] not in sub_tf:
            sub_tf.append(gold_sort[i][1])
        if gold_sort[i][1] not in sub_gene:
            sub_gene.append(gold_sort[i][1])
            sub_gene_exp = np.vstack((sub_gene_exp, np.abs(genes[genes_list.index(gold_sort[i][1])])))
    for i in range(len(gold_sort)):
        if gold_sort[i, 0] in sub_tf and gold_sort[i, 1] in sub_gene:
            pair_list.append(str(gold_sort[i, 0] + ',' + gold_sort[i, 1]))
    print(len(sub_tf), len(sub_gene), sub_gene_exp.shape, u)
    print(len(pair_list), ' Relations,', len(sub_tf), ' TFs,', len(sub_gene), ' Genes')

    return pair_list, sub_tf, sub_gene, sub_gene_exp[1:, :]


#@jit(nopython=True)
def DE(x, window_size):
    # print(x)
    # DE_matrix = np.ones((len(x)-window_size-1,window_size))
    DE_matrix = np.ones((len(x) - window_size - 1, window_size))
    for i in range(len(x) - window_size - 1):
        # temp = []
        for j in range(window_size):
            # print(x[i+j+1],x[i],i)
            DE_matrix[i, j] = np.float(x[i + j + 1]) - np.float(x[i])
            # temp.append(x[i+j+1] -x[i])
    #         temp = np.array(temp)
    #         DE_matrix = np.vstack((DE_matrix,temp))
    return DE_matrix


def GenAllData(sub_gold, sub_tf, sub_gene, sub_gene_exp, window_size,num):  # (gold,tfs,genes,genes_exp):
    error = 0
    all_tf, all_target = [], []
    gene_pair, exp_pair, labels = [], [], []
    for i in range(len(sub_tf)):
        tf_name = sub_tf[i]
        tf_exp = sub_gene_exp[sub_gene.index(tf_name)]
        for j in range(len(sub_gene)):
            target_name = sub_gene[j]
            target_exp = sub_gene_exp[sub_gene.index(target_name)]
            relation = str(tf_name + ',' + target_name)
            #             tf_exp = (tf_exp-tf_exp.mean())/(tf_exp.std())
            #             target_exp = (tf_exp-tf_exp.mean())/(tf_exp.std())
            temp0, temp1 = DE(tf_exp, window_size), DE(target_exp, window_size)
            gene_pair.append(relation)
            all_tf.append(temp0)
            all_target.append(temp1)
            if relation in sub_gold:
                labels.append(1)
            elif relation not in sub_gold:
                labels.append(0)
    if (len(exp_pair) > 0):
        all_tf = np.array(all_tf)[:, :, :, np.newaxis]
        all_target = np.array(all_target)[:, :, :, np.newaxis]
    #         all_tf = all_tf.reshape(all_tf.shape[0],1,all_tf.shape[1],1)
    #         all_target = all_target.reshape(all_tf.shape[0],1,all_tf.shape[1],1)
    if (len(labels) > 0):
        labels = np.array(labels)
    print(len(sub_gold), np.sum(labels))
    print('error:', error)
    np.save('dtf%s.npy'%(num), all_tf)
    np.save('dgene%s.npy'%(num), all_target)
    np.save('dlabel%s.npy'%(num), np.array(labels))
    np.save('dpair%s.npy'%(num), np.array(gene_pair))
    return gene_pair, all_tf, all_target, labels


def split_datasets(labels,num):
    print('labels', np.sum(labels))
    pos_index, neg_index = [], []
    pos_index = [index for index, value in enumerate(labels) if value == 1]
    neg_index = [index for index, value in enumerate(labels) if value == 0]
    pos_shuffle, neg_shuffle = random.sample(pos_index, len(pos_index)), random.sample(neg_index, len(neg_index))
    pos_part, neg_part = len(pos_shuffle) // 5, len(neg_shuffle) // 5
    pos_train, neg_train = pos_shuffle[:3 * pos_part], neg_shuffle[:3 * neg_part]
    pos_val, neg_val = pos_shuffle[3 * pos_part:4 * pos_part], neg_shuffle[3 * neg_part:4 * neg_part]
    pos_test, neg_test = pos_shuffle[4 * pos_part:], neg_shuffle[4 * neg_part:]
    train_index = pos_train + neg_train
    val_index = pos_val + neg_val
    test_index = pos_test + neg_test
    np.save('dtrain_index%s.npy'%(num), np.array(train_index))
    np.save('dval_index%s.npy'%(num), np.array(val_index))
    np.save('dtest_index%s.npy'%(num), np.array(test_index))

    return train_index, val_index, test_index


sub_gold, sub_tf, sub_gene, sub_gene_exp = extract_subdatasets(genes, genes_list, tfs_list, gold, 1000)
gene_pair, all_tf, all_target, labels = GenAllData(sub_gold,sub_tf,sub_gene,sub_gene_exp,32,1000)
train_index,val_index,test_index = split_datasets(labels,1000)
sns.clustermap(sub_gene_exp, xticklabels=True, yticklabels='auto',fmt='d', cmap='RdYlBu',standard_scale=1)
plt.savefig('lac-hot.svg')
plt.show()
sub_gold, sub_tf, sub_gene, sub_gene_exp = extract_subdatasets(genes, genes_list, tfs_list, gold, 5000)
gene_pair, all_tf, all_target, labels = GenAllData(sub_gold,sub_tf,sub_gene,sub_gene_exp,32,5000)
train_index,val_index,test_index = split_datasets(labels,5000)
sns.clustermap(sub_gene_exp, xticklabels=True, yticklabels='auto',fmt='d', cmap='RdYlBu',standard_scale=1)
plt.savefig('lac-hot.svg')
plt.show()
# np.save('dtf5000.npy', all_tf)
# np.save('dgene5000.npy', all_target)
# np.save('dlabel5000.npy', np.array(labels))
# np.save('dpair5000.npy', np.array(gene_pair))
# np.save('dtrain_index5000.npy', np.array(train_index))
# np.save('dval_index5000.npy', np.array(val_index))
# np.save('dtest_index5000.npy', np.array(test_index))
