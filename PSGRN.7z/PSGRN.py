from __future__ import print_function
import tensorflow as tf
import keras
from keras.models import Model
from keras.layers import *
from keras.applications import *
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint
import numpy as np
import matplotlib.pyplot as plt
from sklearn import metrics
import time, os


####################################### parameter settings
batch_size = 128  # mini batch for training
num_classes = 2  # categories of labels
epochs = 50
filters = 128
length = 3

file_dir = '/content/drive/MyDrive/'
model_name = 'final_model.h5'
model_save_dir = file_dir+'maize500/GRU-Independent-/'
if not os.path.isdir(model_save_dir):
    os.makedirs(model_save_dir)

tf_data = np.load(file_dir+'all_tf500.npy')
target_data = np.load(file_dir+'all_target500.npy')
label_data = np.load(file_dir+'labels500.npy')

train_index = np.load(file_dir+'train_index500.npy')
val_index = np.load(file_dir+'val_index500.npy')
test_index = np.load(file_dir+'test_index500.npy')

tf_train = tf_data[train_index]
target_train = target_data[train_index]
y_train = label_data[train_index]
tf_val = tf_data[val_index]
target_val = target_data[val_index]
y_val = label_data[val_index]
tf_test = tf_data[test_index]
target_test = target_data[test_index]
y_test = label_data[test_index]

print(tf_train.shape, 'tf_train samples')
print(target_train.shape, 'target_train samples')
print(tf_val.shape, 'tf_val samples')
print(target_val.shape, 'target_val samples')
print(tf_test.shape, 'tf_test samples')
print(target_test.shape, 'target_test samples')
print(y_train.shape, 'y_train samples')
print(y_val.shape, 'y_val samples')
print(y_test.shape, 'y_test samples')

# calculate running time
inputs_tf = Input(shape=tf_train.shape[1:], name='TF')
inputs_target = Input(shape=tf_train.shape[1:], name='Target')

with tf.name_scope('Time_Feature_Learning'):
    tfs = Reshape((inputs_tf.shape[1], inputs_tf.shape[2]))(inputs_tf)
    target = Reshape((inputs_target.shape[1], inputs_target.shape[2]))(inputs_target)
    tfs, target = GRU(filters, dropout=0.2, return_sequences=True)(tfs), GRU(filters, dropout=0.2, return_sequences=True)(target)
    # tfs, target = SimpleRNN(filters, dropout=0.2, return_sequences=True)(tfs), SimpleRNN(filters, dropout=0.2, return_sequences=True)(target)
    # tfs, target = LSTM(filters, dropout=0.2, return_sequences=True)(tfs), LSTM(filters, dropout=0.2, return_sequences=True)(target)
    tfs, target = tf.expand_dims(tfs, -1), tf.expand_dims(target, -1)
    x = concatenate([tfs, target])

with tf.name_scope('Spatial feature learning'):
    x = tf.keras.applications.convnext.ConvNeXtBase(input_shape=(tf_train.shape[1], filters, 2),include_top=False, weights=None,classes=num_classes)(x)
    # x = resnet.ResNet50(input_shape=(tf_train.shape[1], filters, 2),include_top=False, weights=None,classes=num_classes)(x)
    # x = vgg.VGG16(input_shape=(tf_train.shape[1], filters, 2),include_top=False, weights=None,classes=num_classes)(x)
    x = BatchNormalization()(x)
    output = Dense(1, activation='softmax')(Dropout(0.5)(Dense(512, activation='relu')(Flatten()(x))))

model = Model(inputs=[inputs_tf, inputs_target], outputs=output)
model.compile(optimizer=Adam(), loss='binary_crossentropy', metrics=['accuracy'])

model.summary()
checkpoint = ModelCheckpoint(filepath=model_save_dir+'best_model.hdf5', monitor='val_accuracy', verbose=1, save_best_only=True, mode='auto', save_weights_only=False, save_freq="epoch")
start_time = time.time()
history = model.fit(
    {'TF': tf_train, 'Target': target_train}, y_train,
    validation_data=({'TF': tf_val, 'Target': target_val}, y_val),
    batch_size=batch_size,
    epochs=epochs,
    # validation_split=0.2,
    shuffle=True,
    callbacks=checkpoint
)
end_time = time.time()
print('spend time:',(end_time-start_time)/60, 'min')
# Save model and weights
model_path = os.path.join(model_save_dir, model_name)
model.save(model_path)
print('Saved trained model at %s ' % model_path)
y_predict = model.predict({'TF': tf_test, 'Target': target_test})
precision, recall, thresholds_PR = metrics.precision_recall_curve(y_test, y_predict)

# print('Running time:'+str(end-start))

############################################################################## plot training process
plt.figure(figsize=(10, 6))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.grid()
plt.legend(['train', 'val'], loc='upper left')
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'val'], loc='upper left')
plt.grid()
plt.savefig(model_save_dir + 'train_process.pdf')

###############################################################  evaluation without consideration of data separation
plt.figure(figsize=(10, 6))
fpr, tpr, thresholds = metrics.roc_curve(y_test, y_predict, pos_label=1)
auc = metrics.auc(fpr, tpr)
plt.plot(fpr, tpr, label='AUROC = %0.5f)' % auc)
plt.grid()
plt.plot([0, 1], [0, 1])
plt.title('ROC curve')
plt.xlabel('FP')
plt.ylabel('TP')
plt.ylim([0, 1])
plt.xlim([0, 1])
plt.legend(loc="lower right")
print('AUC in figure:', auc)
plt.savefig(model_save_dir + 'AUCofTest.pdf')

precision, recall, thresholds_PR = metrics.precision_recall_curve(y_test, y_predict)
AUPR = metrics.auc(recall, precision)
pr_curve = plt.figure(1)
plt.plot(precision, recall, label='Area Under the Curve (AUPR = %0.5f)' % AUPR)
plt.title('PR curve')
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.legend(loc="lower right")
plt.ylim([0, 1])
plt.xlim([0, 1])
plt.savefig(model_save_dir + 'AUPRofTest.pdf')
print("AUPR in figure:", AUPR)
