import csv
import pandas as pd
import numpy as np
import time
import random
import matplotlib.pyplot as plt
from multiprocessing import cpu_count
from concurrent.futures import ProcessPoolExecutor
#
# def extract_subdatasets(genes, genes_list, tfs_list, gold, size):
#     print('Dataset Extracting......')
#     u = 0
#     pair = np.ones((1, gold.shape[1]))
#     pair_list = []
#     sub_tf, sub_gene = [], []
#     sub_tf_exp, sub_gene_exp = np.zeros((1, genes.shape[1])), np.zeros((1, genes.shape[1]))
#     for i in range(len(gold)):
#         tf_name = gold[i, 0][-14:]
#         target_name = gold[i, 1]
#         p_value = gold[i, 2]
#         if tf_name in tfs_list and target_name in genes_list:
#             if np.mean(genes[genes_list.index(tf_name), :]) > 1 and np.mean(
#                     genes[genes_list.index(target_name), :]) > 1 and p_value < 0.01:
#                 temp = np.array([tf_name, target_name, p_value])
#                 pair = np.vstack((pair, temp))
#     pair = pair[1:, :]
#     gold_sort = pair[np.argsort(pair[:, 2], ), :]
#     print(len(gold), len(gold_sort))
#     for i in range(size):
#         if gold_sort[i][0] not in sub_tf:
#             sub_tf.append(gold_sort[i][0])
#             sub_tf_exp = np.vstack((sub_tf_exp, genes[genes_list.index(gold_sort[i][0]), :]))
#         if gold_sort[i][0] not in sub_gene:
#             sub_gene.append(gold_sort[i][0])
#             sub_gene_exp = np.vstack((sub_gene_exp, genes[genes_list.index(gold_sort[i][0]), :]))
#         if gold_sort[i][1] in tfs_list and gold_sort[i][1] not in sub_tf:
#             sub_tf.extend([gold_sort[i][1]])
#             sub_tf_exp = np.vstack((sub_tf_exp, genes[genes_list.index(gold_sort[i][1]), :]))
#         if gold_sort[i][1] not in sub_gene:
#             sub_gene.extend([gold_sort[i][1]])
#             sub_gene_exp = np.vstack((sub_gene_exp, genes[genes_list.index(gold_sort[i][1]), :]))
#     for i in range(len(gold_sort)):
#         if gold_sort[i, 0] in sub_tf and gold_sort[i, 1] in sub_gene:
#             pair_list.append(str(gold_sort[i, 0] + ',' + gold_sort[i, 1]))
#     print(len(sub_tf), len(sub_gene), sub_gene_exp.shape, u)
#     print(len(pair_list), ' Relations,', len(sub_tf), ' TFs,', len(sub_gene), ' Genes')
#
#     return pair_list, sub_tf, sub_tf_exp[1:, :], sub_gene, sub_gene_exp[1:, :]
#
# def DE(x, window_size):
#     # print(x)
#     # DE_matrix = np.ones((len(x)-window_size-1,window_size))
#     DE_matrix = np.ones((len(x)-window_size-1, window_size))
#     for i in range(len(x)-window_size-1):
#         # temp = []
#         for j in range(window_size):
#             # print(x[i+j+1],x[i],i)
#             DE_matrix[i, j] = np.float(x[i + j + 1]) - np.float(x[i])
#             # temp.append(x[i+j+1] -x[i])
#     #         temp = np.array(temp)
#     #         DE_matrix = np.vstack((DE_matrix,temp))
#     return DE_matrix
#
#
# def GenAllData(paras):  # (gene_part, sub_tf, sub_tf_exp, genesexp_part, sub_gold, time_lag)
#     # error = 0
#     pair_matrix, gene_pair, labels = [], [], []
#     sub_gene, sub_tf, sub_tf_exp, sub_gene_exp, sub_gold, time_lag, points = paras[0], paras[1], paras[2], paras[3], paras[4], paras[5], paras[6]
#     for i in range(len(sub_tf)):
#         tf_name = sub_tf[i]
#         tf_exp = sub_tf_exp[sub_tf.index(tf_name)]
#         tf_exp = 100 * (tf_exp - tf_exp.mean()) / (tf_exp.std())
#         for j in range(len(sub_gene)):
#             target_name = sub_gene[j]
#             target_exp = sub_gene_exp[sub_gene.index(target_name)]
#             relation = str(tf_name + ',' + target_name)
#             target_exp = 100 * (target_exp-target_exp.mean())/(target_exp.std())
#             temp0 = []
#             for window in range(len(tf_exp)-time_lag-points):
#                 current_tf = pd.Series(tf_exp[window:window+time_lag])
#                 temp1 = []
#                 for p in range(len(target_exp), len(target_exp)+points):
#                     current_target = pd.Series(tf_exp[window+p:window+p+time_lag])
#                     pcc = current_tf.corr(current_target, method="pearson")
#                     temp1.append(pcc)
#                 if temp0 == []:
#                     temp0 = np.array(temp1)
#                 else:
#                     temp0 = np.vstack((temp0, np.array(temp1)))
#             pair_matrix.append(temp0)
#
#             gene_pair.append(relation)
#             if relation in sub_gold:
#                 labels.append(1)
#             else:
#                 labels.append(0)
#     # print(len(sub_gold), np.sum(labels))
#     # print('error:', error)
#     return (pair_matrix, gene_pair, labels)
#
# def multi_processing(gene_part, sub_tf, sub_tf_exp, genesexp_part, sub_gold, cores, time_lag, points):
#     print('Multi-core processing...')
#     start = time.time()
#     if __name__ == '__main__':
#         pair_matrix, gene_pair, labels = [], [], []
#         p = ProcessPoolExecutor(max_workers=cores)
#         process = [p.submit(GenAllData, (gene_part[i], sub_tf, sub_tf_exp, genesexp_part[i], sub_gold, time_lag, points)) for i in range(cores)]
#         p.shutdown()
#
#         for j in range(cores):
#             results = process[j].result()
#             pair_matrix.extend(results[0])
#             gene_pair.extend(results[1])
#             labels.extend(results[2])
#
#         end = time.time()
#         RuningTime = end - start
#         print('multiprocessing Done! Runing Time:', round(RuningTime / 60, 2), 'min')
#
#     label0, label1 = 0, 0
#
#     # calculating density of labels
#     for i in labels:
#         if i == 1:
#             label1 += 1
#         elif i == 0:
#             label0 += 1
#         else:
#             print('label error!')
#
#     print('Density=' + str(label1 / (label1 + label0)))
#
#     return pair_matrix, gene_pair, labels
#
#
# def split_datasets(labels):
#     print('labels', np.sum(labels))
#     pos_index, neg_index = [], []
#     pos_index = [index for index, value in enumerate(labels) if value == 1]
#     neg_index = [index for index, value in enumerate(labels) if value == 0]
#     pos_shuffle, neg_shuffle = random.sample(pos_index, len(pos_index)), random.sample(neg_index, len(neg_index))
#     pos_part, neg_part = len(pos_shuffle) // 5, len(neg_shuffle) // 5
#     pos_train, neg_train = pos_shuffle[:3 * pos_part], neg_shuffle[:3 * neg_part]
#     pos_val, neg_val = pos_shuffle[3 * pos_part:4 * pos_part], neg_shuffle[3 * neg_part:4 * neg_part]
#     pos_test, neg_test = pos_shuffle[4 * pos_part:], neg_shuffle[4 * neg_part:]
#     train_index = pos_train + neg_train
#     val_index = pos_val + neg_val
#     test_index = pos_test + neg_test
#
#     return train_index, val_index, test_index
#
# def genes_split(gene, gene_exp):
#     cores = cpu_count()
#     part = (gene_exp.shape[0] // (cores)) + 1
#
#     if cores >= 4:
#         # part = len(gene) // (cores-1)
#         genesexp_part = []
#         gene_part = []
#         for i in range(cores):
#             a = min((i + 1) * part, gene_exp.shape[0])
#             temp = gene_exp[[col for col in range(i * part, a)], :]
#             temp1 = gene[i * part:a]
#             genesexp_part.append(temp)
#             gene_part.append(temp1)
#         return gene_part, genesexp_part, cores
#     else:
#         print('CPU cores less than 4!！!')
#         return 0
#
#
#
# if __name__ == '__main__':
#     # construct maize1000, maize5000 datasets
#     genes = pd.read_csv('all_genes.csv', index_col=0, engine='c')
#     if np.any(genes.isnull()):
#         print('matrix has null, check again before submit!')
#     genes_list = list(genes.index)
#     genes = genes.values
#     # print(np.isnan(genes))
#     tfs = pd.read_csv('all_tf.csv', index_col=0, engine='c')
#     tfs_list = list(tfs.index)
#     tfs = tfs.values.T
#     gold = pd.read_csv('GSE137972_TF_target_TIP.csv', sep=',', engine='c').values
#     print(gold.shape)
#     time_lag, points = 32, 15
#
#     sub_gold, sub_tf, sub_tf_exp, sub_gene, sub_gene_exp = extract_subdatasets(genes, genes_list, tfs_list, gold, 500)
#
y_predict1 = np.load('y_predict1.npy').reshape(-1)
labels500 = np.load('labels500.npy')
regs = np.load('gene_pair500.npy')
#找出前20%的分类
argsort = np.argsort(y_predict1)[::-1][int(0.2*len(y_predict1))]

y_predict = np.where(y_predict1>=y_predict1[argsort], 1, 0)

#列出每个TF的边
tfs, targets, regulations = [], [], []
for i in range(len(regs)):
    reg = regs[i]
    temp = reg.find(',')
    tf = reg[:temp]
    target = reg[temp+1:]
    if y_predict[i] == 1:
        if tf not in tfs:
            tfs.append(tf)
            targets.append([reg[temp+1:]])
            regulations.append(1)
        else:
            regulations[tfs.index(tf)] += 1
            temp1 = targets[tfs.index(tf)]
            temp1.append(reg[temp+1:])
            targets[tfs.index(tf)] = temp1
print(np.sum(regulations))
#边数按从大到小排列
argsort = np.argsort(regulations)[::-1]
tfs1, regulations1 = [], []

for num in argsort:
    tfs1.append(tfs[num])
    regulations1.append(regulations[num])

print(len(targets))

att = np.empty((1,3))
for tf in range(len(targets)):
    temp = np.array([tfs1[tf], str(targets[tf])[1:-2], regulations[tf]])
    att = np.vstack((att, temp))
att = pd.DataFrame(att[1:,:], columns=['TF id', 'Targets', 'Number of regulations'])
att.to_csv('maize-1 prediction.csv', index=False)
#画柱状图
# plt.figure(dpi=300,figsize=(24,8))
# plt.bar(np.arange(len(tfs)), regulations1, label='edges', color='slategrey', width=0.8)
# # plt.xlabel('TF ids')
# plt.ylabel('Number of edges', fontsize=20)
# # plt.axis([tf for tf in range(0, len(tfs1), 5)])
# plt.xticks(np.arange(0, len(tfs), 5), fontsize=20)
# plt.tick_params(labelsize=20)
# plt.savefig('analyse1.jpg')
# plt.show()
# print(np.sum(regulations1[:7])/np.sum(regulations1))
# plt.figure(dpi=300,figsize=(10,12))
# plt.barh(tfs[:15][::-1], regulations1[:15][::-1], label='edges', color='slategrey')
# # plt.xlabel('TF ids')
# # plt.ylabel('number of edges', fontsize=20)
# # plt.axis([tf for tf in range(0, len(tfs1), 5)])
# plt.xticks(fontsize=15)
# plt.tick_params(labelsize=15)
# plt.savefig('analyse1.jpg')
# plt.show()
#
# print(tfs[:15])



